This collection is contains all the same text, but saved using different applications. The original file is captured in screenshot_orig.png
